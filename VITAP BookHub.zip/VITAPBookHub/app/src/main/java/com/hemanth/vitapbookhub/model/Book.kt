package com.hemanth.vitapbookhub.model

data class Book (
   // val bookid:Int,
    val bookName:String,
    val bookAuthor:String,
    val bookUrl:String,
    val bookimage:Int
)